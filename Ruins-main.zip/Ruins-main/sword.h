#ifndef __SWORD_H__
#define __SWORD_H__

#include "equipment.h"

class sword: public equipment {
public:
    sword(int solidity);
};

#endif