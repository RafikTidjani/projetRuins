//
// Created by Arthur Mathis on 20/11/2023.
//
#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"
