var searchData=
[
  ['red_0',['RED',['../classdisplay_console.html#acb7cbf9a6aade67b9d05ccc733450c06',1,'displayConsole']]]
];
