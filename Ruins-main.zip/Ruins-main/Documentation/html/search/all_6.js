var searchData=
[
  ['hability_0',['hability',['../classmonster.html#a3aec9cd4864a53884a56aebfac0838d2',1,'monster']]],
  ['hasamulet_1',['hasAmulet',['../classbox.html#a732eb7fd83d3c65e2f5bb1a37c3abe47',1,'box']]],
  ['hasbeenattacked_2',['hasBeenAttacked',['../classadventurer.html#aab9fec39842276954e766ce38580569f',1,'adventurer::hasBeenAttacked()'],['../classcharacter.html#a6e94f0f89bbc55fe1e886df5b0285ad7',1,'character::hasBeenAttacked()'],['../classmonster.html#a60639ec8c29ed0b95e74696b06d67325',1,'monster::hasBeenAttacked()']]],
  ['hascoins_3',['hasCoins',['../classbox.html#aaf23ecf3f29d029c1581023eccb02ebc',1,'box']]],
  ['health_4',['health',['../classcharacter.html#a528ba35a3478e9800d3b93fc2a58cd7c',1,'character']]]
];
