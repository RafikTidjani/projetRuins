var searchData=
[
  ['green_0',['GREEN',['../classdisplay_console.html#a812f9b3486d254d281db9c81793b705b',1,'displayConsole']]]
];
