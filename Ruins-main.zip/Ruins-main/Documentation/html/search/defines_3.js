var searchData=
[
  ['rules_0',['RULES',['../game_8h.html#af49cc0b753734f0d0d70298eae0786a0',1,'game.h']]]
];
