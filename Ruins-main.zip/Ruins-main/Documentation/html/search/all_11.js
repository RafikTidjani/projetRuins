var searchData=
[
  ['x_0',['x',['../classcoord.html#a96128553986da98204ca1562fb63707b',1,'coord']]]
];
