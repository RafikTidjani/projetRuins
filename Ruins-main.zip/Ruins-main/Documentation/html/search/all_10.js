var searchData=
[
  ['white_0',['WHITE',['../classdisplay_console.html#acc6f95902ca02ccff9cbcd8aedd3ddcd',1,'displayConsole']]]
];
