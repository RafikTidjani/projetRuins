var searchData=
[
  ['takeamulet_0',['takeAmulet',['../classadventurer.html#a6e76232512fdc60399e0ed9aa92185f6',1,'adventurer']]],
  ['type_1',['type',['../classbox.html#a5f6fad983cde19a322d37a468f93e6a2',1,'box::type()'],['../classcharacter.html#a241971a3572165a3f6dc42d0b8c56037',1,'character::type()']]],
  ['typecode_2',['typeCode',['../classcastle.html#aa8272df9e3a8b9e376b17215ccbdfc52',1,'castle']]]
];
