var searchData=
[
  ['move_5fto_5fplayer_5fdistance_0',['MOVE_TO_PLAYER_DISTANCE',['../classmonster.html#a531032a2cf823583c3ed927a705c164d',1,'monster']]]
];
