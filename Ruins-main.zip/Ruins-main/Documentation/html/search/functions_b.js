var searchData=
[
  ['position_0',['position',['../classcharacter.html#ac0bcc42807776bf97738898b23cf0dc6',1,'character']]],
  ['putcharacter_1',['putCharacter',['../classbox.html#a10d67a6897ae77c4c12d93d945b7e949',1,'box']]]
];
