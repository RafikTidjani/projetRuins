var searchData=
[
  ['purple_0',['PURPLE',['../classdisplay_console.html#ad99a85ee24fad0936f2941fefee7d95d',1,'displayConsole']]]
];
