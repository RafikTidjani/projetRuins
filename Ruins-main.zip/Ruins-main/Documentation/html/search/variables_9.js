var searchData=
[
  ['yellow_0',['YELLOW',['../classdisplay_console.html#ae6288bdf37576e36319377c10f3456b7',1,'displayConsole']]]
];
