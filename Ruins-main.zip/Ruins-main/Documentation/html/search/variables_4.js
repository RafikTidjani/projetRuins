var searchData=
[
  ['info_5fdistance_0',['INFO_DISTANCE',['../classmonster.html#a406ad65296e85e75e1c232bdfc60c95b',1,'monster']]]
];
