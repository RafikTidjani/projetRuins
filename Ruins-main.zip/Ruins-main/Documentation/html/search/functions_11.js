var searchData=
[
  ['y_0',['y',['../classcoord.html#add4fe7cb9b2d056f18d3061fd924ed87',1,'coord']]]
];
