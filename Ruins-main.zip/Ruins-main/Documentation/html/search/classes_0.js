var searchData=
[
  ['adventurer_0',['adventurer',['../classadventurer.html',1,'']]],
  ['armor_1',['armor',['../classarmor.html',1,'']]]
];
