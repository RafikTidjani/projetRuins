var searchData=
[
  ['legend_0',['LEGEND',['../game_8h.html#ad511448a00f508722168bec69d394687',1,'game.h']]]
];
