#include "armor.h"

armor::armor(int solidity): equipment{solidity} {
}
