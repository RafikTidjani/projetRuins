#include "sword.h"

sword::sword(int solidity): equipment{solidity}{
}
